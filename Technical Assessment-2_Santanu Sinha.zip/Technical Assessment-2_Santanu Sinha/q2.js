var Char = prompt("Enter the value:");
var grade = '';
switch (Char) {
    case "A":
        {
            grade = ("Excellent");
            alert(grade);
            break;
        }
    case "B":
        {
            grade = ("Good");
            alert(grade);
            break;
        }
    case "C":
        {
            grade = ("Fair");
            alert(grade);
            break;
        }
    case "D":
        {
            grade = ("Poor");
            alert(grade);
            break;
        }
    default:
        {
            alert("Invalid input");
            break;
        }
}
